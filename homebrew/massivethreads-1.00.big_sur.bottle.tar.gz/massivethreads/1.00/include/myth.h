/* 
 * myth.h
 */

/* 
 this file is installed by MassiveThreads 0.50,
 in order to signal an error to the user who
 includes <myth.h>, not <myth/myth.h>, according
 to the old installation.
 */

#error "from version 0.50 and on, you should include <myth/myth.h>, not <myth.h>"
