/* 
 * myth_sync.c
 */

#include "myth_config.h"
#include "myth_sync_func.h"

//All the functions are written in myth_sync_func.h to minimize overheads by inlining
