#include "myth_dag_random.c"
