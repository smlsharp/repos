#include "myth_dag_1d.c"
