#include "measure_wakeup_latency.c"
