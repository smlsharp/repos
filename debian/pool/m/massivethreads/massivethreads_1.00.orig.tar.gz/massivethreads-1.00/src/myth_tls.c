/*
 * myth_tls.c
 *
 *  Created on: 2011/05/17
 *      Author: jnakashima
 */

#include "myth/myth.h"
#include "myth_config.h"
#include "myth_tls_func.h"

myth_tls_key_allocator_t g_myth_tls_key_allocator[1];


