CREATE TABLE people (
  name   text not null,
  age    int not null
);
